<?php $__env->startSection('title'); ?>
	Social Network - Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<br>
	<br>
	<br>
	<br>
	<div class="col-md-4 col-md-offset-4">
	<?php if(Session::has('err_message')): ?>
		<div class="alert alert-danger text-center"><?php echo e(Session::get('err_message')); ?></div>
	<?php endif; ?>
	<div class="panel panel-default">
		<div class="panel-heading">Login</div>
		<div class="panel-body">
			<form action="<?php echo e(url('/login')); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

				<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
					<input type="text" class="form-control" name="email" placeholder="Email">
					<?php if($errors->has('email')): ?>
						<span class="help-block">
							<?php echo e($errors->first('email')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
					<input type="password" class="form-control" name="password" placeholder="Password">
					<?php if($errors->has('password')): ?>
						<span class="help-block">
							<?php echo e($errors->first('password')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-primary">Login</button>
				</div>
			</form>
		</div>
	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>