<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<?php if($post->user_id == Auth::user()->id): ?>
<!-- Media top -->
<div class="media">
  <div class="media-left media-top">
    <a href="<?php echo e(url('profile/'.$post->user->id)); ?>">
    	<img src="uploads/images/profile_pic/<?php echo e($post->user->id); ?>.jpg" class="media-object post_pic">
    </a>
  </div>
  <div class="media-body">
    <h4 class="media-heading"><?php echo e($post->user->firstname); ?> <?php echo e($post->user->lastname); ?><small class="pull-right"><i>Posted <?php echo e($post->created_at->diffForHumans()); ?></i></small></h4>
    <p><?php echo e($post->post); ?></p>

    <br>
    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="media">
			<div class="media-left media-top">
			<a href="<?php echo e(url('profile/'.$comment->user->id)); ?>">
				<img src="uploads/images/profile_pic/<?php echo e($comment->user->id); ?>.jpg" class="media-object post_pic">
			</a>
			</div>
			<div class="media-body">
			<h4 class="media-heading"><?php echo e($comment->user->firstname); ?> <?php echo e($comment->user->lastname); ?><small class="pull-right"><i><?php echo e($comment->created_at->diffForHumans()); ?></i></small></h4>
			<p><?php echo e($comment->comment); ?></p>

			<br>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <div class="form-group col-md-11 col-md-offset-1 comment_box">
	<textarea class="form-control" placeholder="Comment" rows="2"></textarea>
	<div>
		<br>
		<button type="submit" class="btn btn-success enter_btn" data-postid="<?php echo e($post->id); ?>">Enter</button>
	</div>
  </div>

</div>

<br>
<br>

<?php else: ?>
	<?php if(Auth::user()->id < $post->user_id): ?>
		<?php $user1_id = Auth::user()->id; ?>
		<?php $user2_id = $post->user_id; ?>
	<?php else: ?>
		<?php $user1_id = $post->user_id; ?>
		<?php $user2_id = Auth::user()->id; ?>
	<?php endif; ?>

	<?php $__currentLoopData = $relationships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($rel->user1 == $user1_id AND $rel->user2 == $user2_id AND $rel->status_id == 2): ?>
			<!-- Media top -->
			<div class="media">
			  <div class="media-left media-top">
			  <a href="<?php echo e(url('profile/'.$post->user->id)); ?>">
			  	<img src="uploads/images/profile_pic/<?php echo e($post->user->id); ?>.jpg" class="media-object post_pic">
			  </a>
			  </div>
			  <div class="media-body">
			    <h4 class="media-heading"><?php echo e($post->user->firstname); ?> <?php echo e($post->user->lastname); ?><small class="pull-right"><i>Posted <?php echo e($post->created_at->diffForHumans()); ?></i></small></h4>
			    <p><?php echo e($post->post); ?></p>

			    <br>
			    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="media">
						<div class="media-left media-top">
						<a href="<?php echo e(url('profile/'.$comment->user->id)); ?>">
							<img src="uploads/images/profile_pic/<?php echo e($comment->user->id); ?>.jpg" class="media-object post_pic">
						</a>
						</div>
						<div class="media-body">
						<h4 class="media-heading"><?php echo e($comment->user->firstname); ?> <?php echo e($comment->user->lastname); ?><small class="pull-right"><i><?php echo e($comment->created_at->diffForHumans()); ?></i></small></h4>
						<p><?php echo e($comment->comment); ?></p>

						<br>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </div>

			  <div class="form-group col-md-11 col-md-offset-1 comment_box">
				<textarea class="form-control" placeholder="Comment" rows="2"></textarea>
				<div>
					<br>
					<button type="submit" class="btn btn-success enter_btn" data-postid="<?php echo e($post->id); ?>">Enter</button>
				</div>
			  </div>

			</div>

			<br>
			<br>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<p>Zero Post.</p>
<?php endif; ?>

<script src="<?php echo e(url('/js/comment.js')); ?>"></script>