<?php $__env->startSection('title'); ?>
	Edit Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div>
		<?php if(Session::has('updateSuccess')): ?>
			<div class="alert alert-success">
				<?php echo e(Session::get('updateSuccess')); ?>

			</div>
		<?php endif; ?>
	</div>
	<div class="panel panel-default">
		<div class="panel-heading">Edit Profile</div>
		<div class="panel-body">
			<form action="<?php echo e(url('/updateProfile')); ?>" method="POST" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>

				<div class="form-group <?php echo e($errors->has('firstname') ? 'has-error': ''); ?>">
					<label for="firstname">Firstname: </label>
					<input class="form-control" type="text" name="firstname" value="<?php echo e($user->firstname); ?>">
					<?php if($errors->has('firstname')): ?>
						<span class="help-block">
							<?php echo e($errors->first('firstname')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('lastname') ? 'has-error': ''); ?>">
					<label for="lastname">Lastname: </label>
					<input class="form-control" type="text" name="lastname" value="<?php echo e($user->lastname); ?>">
					<?php if($errors->has('lastname')): ?>
						<span class="help-block">
							<?php echo e($errors->first('lastname')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('newPassword') ? 'has-error': ''); ?>">
					<label for="password">New Password: </label>
					<input class="form-control" type="password" name="newPassword">
					<?php if($errors->has('newPassword')): ?>
						<span class="help-block">
							<?php echo e($errors->first('newPassword')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('confirmPassword') ? 'has-error': ''); ?>">
					<label for="password">Confirm Password: </label>
					<input class="form-control" type="password" name="confirmPassword">
					<?php if($errors->has('confirmPassword')): ?>
						<span class="help-block">
							<?php echo e($errors->first('confirmPassword')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group">
					<label for="profile_pic">Upload Image: </label>
					<input class="form-control" type="file" name="profile_pic">
				</div>
				<div>
					<button class="btn btn-danger" type="submit">Edit</button>
				</div>
			</form>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>