<?php $__env->startSection('title'); ?>
	Friend Request
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h3>Friend Request</h3>
	<hr>
	<table id="friend_request_tbl">
		<?php $__empty_1 = true; $__currentLoopData = $friendRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friendRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<tr>
		<td>
		<h4>
			<a href="<?php echo e(url('profile/'.$friendRequest->users->id)); ?>">
			<img src="uploads/images/profile_pic/<?php echo e($friendRequest->users->id); ?>.jpg" class="requester_pic">
			</a><?php echo e($friendRequest->users->firstname); ?> <?php echo e($friendRequest->users->lastname); ?>

		</h4>
		</td>
		<td>
		<button type="submit" class="btn btn-info rel_btn" data-user1="<?php echo e($friendRequest->user1); ?>" data-user2="<?php echo e($friendRequest->user2); ?>" data-action="<?php echo e($friendRequest->action_user_id); ?>" data-status="2">Confirm</button>
		</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<p>No Friend Request</p>
		<?php endif; ?>
	</table>

	<script>
		var urlUpdateRel = "<?php echo e(url('/updateRel')); ?>";
		var token = "<?php echo e(Session::token()); ?>";
		var userId = " <?php echo e(Auth::user()->id); ?> ";
	</script>
	<script src="<?php echo e(url('js/update_rel.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>