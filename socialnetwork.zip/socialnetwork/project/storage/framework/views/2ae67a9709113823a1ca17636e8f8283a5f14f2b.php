<?php $__env->startSection('title'); ?>
	Social Network - Index
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<h1>Index Page</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>