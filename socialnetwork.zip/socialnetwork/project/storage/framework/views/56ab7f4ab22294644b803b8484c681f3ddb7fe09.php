<?php $__env->startSection('title'); ?>
	Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-3">
	<div id="profile_pic">
		<img class="img-responsive" src="/uploads/images/profile_pic/<?php echo e($user->id); ?>.jpg" alt="profile picture">
	</div>

	<br>

	<a class="btn btn-primary" href="<?php echo e(url('/messages')); ?>">Send Message</a>
</div>

<div class="col-md-9">
	<div class="form-group <?php echo e($errors->has('post') ? 'has-error' : ''); ?>">
		<input type="hidden" name="user_id" value="1">
		<textarea id="post_body" class="form-control" name="post" placeholder="Write Post" rows="8"></textarea>
		<?php if($errors->has('post')): ?>
			<span class="help-block">
				<?php echo e($errors->first('post')); ?>

			</span>
		<?php endif; ?>
	</div>
	<button type="submit" id="post_btn" class="btn btn-primary btn-lg pull-right">Post</button>

	<br><br><hr><br><br>	

	<!-- display all posts -->
	<div id="profile_posts"></div>

	<br><br>
</div>

<script>
	var userId = "<?php echo e(Auth::user()->id); ?>";
	var token = "<?php echo e(Session::token()); ?>";
	var urlPost = "<?php echo e(url('/addPost')); ?>";
	var urlComment = "<?php echo e(url('/addComment')); ?>";
	var urlProfilePostsDisplay = "<?php echo e(url('/profileposts/'.$user->id)); ?>";
</script>

<script type="text/javascript" src="<?php echo e(url('js/profile_posts.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>