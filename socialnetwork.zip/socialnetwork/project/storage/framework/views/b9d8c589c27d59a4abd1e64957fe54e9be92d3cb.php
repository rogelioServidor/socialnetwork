
	<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<!-- hide auth user -->
		<?php if($user->id != Auth::user()->id): ?>
			<!-- add value to user1 and user2 -->
			<?php if(Auth::user()->id < $user->id): ?>
				<?php $user1_id = Auth::user()->id; ?>
				<?php $user2_id = $user->id; ?>
			<?php else: ?>
				<?php $user1_id = $user->id; ?>
				<?php $user2_id = Auth::user()->id; ?>
			<?php endif; ?>
			
			<tr>
			<!-- display relationships -->
			<?php $__empty_2 = true; $__currentLoopData = $relationships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
				<?php if($r->user1 == $user1_id AND $r->user2 == $user2_id): ?>			
					<?php if($r->status->status == 'pending'): ?>
						<?php if($r->action_user_id == Auth::user()->id): ?>
							<td>
							<h4><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
							</td>
							<td>
							<button type="submit" class="btn btn-success rel_btn">Friend Request Sent</button>
						<?php else: ?>
							<td>
							<h4><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
							</td>
							<td>
							<button type="submit" class="btn btn-info rel_btn">Confirm</button>
						<?php endif; ?>
					<?php elseif($r->status->status == 'accepted'): ?>
						<td>
						<h4><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
						</td>
						<td>
						<button type="submit" class="btn btn-warning rel_btn">Unfriend</button>
					<?php elseif($r->status->status == 'declined'): ?>
						<td>
						<h4><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
						</td>
						<td>
						<button type="submit" class="btn btn-primary rel_btn">Add Friend</button>
					<?php endif; ?>
					
					<?php $counter = 0; ?>
					<?php break; ?>
				<?php else: ?>
					<?php $counter++ ;?>
					<?php if($r->count() == $counter): ?>
						<td>
						<h4><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
						</td>
						<td>
						<button type="submit" class="btn btn-primary rel_btn">Add Friend</button>
						<?php $counter = 0; ?>
						<?php break; ?>
					<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
				Add
			<?php endif; ?>
			</td>
			</tr>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<p>No Results Found.</p>
	<?php endif; ?>


	<script>
	var urlPeople = "<?php echo e(url('/searchPeople')); ?>";
	</script>
	<script src="<?php echo e(url('js/people.js')); ?>"></script>