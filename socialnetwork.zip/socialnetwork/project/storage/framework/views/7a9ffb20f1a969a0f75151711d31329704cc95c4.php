<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header col-md-3">
      <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">Social Network</a>
    </div>
    
    <?php if(Auth::check()): ?>
      <form id="search" class="form-inline col-md-6" action="<?php echo e(url('/search')); ?>">
        <div class="form-group">
          <input id="search_val" class="form-control" type="text" name="search" value="<?php if(isset($_GET['search'])){ echo $_GET['search']; } ?>" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-primary pull-right" >Search</button>
      </form>
    <?php endif; ?>

    <?php if(Auth::check()): ?>
      <div class="dropdown col-md-2 col-md-offset-1" style="margin-top: 7px;">
      <button class="btn btn-danger dropdown-toggle" type="button" data-toggle="dropdown"><?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastname); ?>

      <span class="caret"></span></button>
      <ul class="dropdown-menu" style="margin-left: 15px;">
        <li><a href="<?php echo e(url('/editProfile')); ?>">Edit Profile</a></li>
        <li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
      </ul>
    </div>
    <?php else: ?>
      <ul class="nav navbar-nav col-md-1 col-md-offset-2 pull-right">
      <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
      </ul>
    <?php endif; ?>
    
  </div>
</nav>