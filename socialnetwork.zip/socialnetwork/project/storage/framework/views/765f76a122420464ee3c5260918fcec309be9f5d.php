<?php $__env->startSection('title'); ?>
	Search
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h3>People</h3>
	<hr>
	<table id="rel_tbl">
	<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<!-- hide auth user -->
		<?php if($user->id != Auth::user()->id): ?>
			<!-- add value to user1 and user2 -->
			<?php if(Auth::user()->id < $user->id): ?>
				<?php $user1_id = Auth::user()->id; ?>
				<?php $user2_id = $user->id; ?>
			<?php else: ?>
				<?php $user1_id = $user->id; ?>
				<?php $user2_id = Auth::user()->id; ?>
			<?php endif; ?>
			
			<tr>
			<!-- display relationships -->
			<?php $__empty_2 = true; $__currentLoopData = $relationships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
				<?php if($r->user1 == $user1_id AND $r->user2 == $user2_id): ?>			
					<?php if($r->status->status == 'pending'): ?>
						<?php if($r->action_user_id == Auth::user()->id): ?>
							<td>
							<h4><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
							</td>
							<td>
							<button type="submit" class="btn btn-success rel_btn" disabled>Friend Request Sent</button>
						<?php else: ?>
							<td>
							<h4><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
							</td>
							<td>
							<button type="submit" class="btn btn-info rel_btn" data-user1="<?php echo e($user1_id); ?>" data-user2="<?php echo e($user2_id); ?>" data-action="<?php echo e($r->action_user_id); ?>" data-status="<?php echo e($r->status_id); ?>">Confirm</button>
						<?php endif; ?>
					<?php elseif($r->status->status == 'accepted'): ?>
						<td>
						<h4><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
						</td>
						<td>
						<button type="submit" class="btn btn-warning rel_btn" data-user1="<?php echo e($user1_id); ?>" data-user2="<?php echo e($user2_id); ?>" data-action="<?php echo e($r->action_user_id); ?>" data-status="<?php echo e($r->status_id); ?>">Unfriend</button>
					<?php elseif($r->status->status == 'declined'): ?>
						<td>
						<h4><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
						</td>
						<td>
						<button type="submit" class="btn btn-primary rel_btn" data-user1="<?php echo e($user1_id); ?>" data-user2="<?php echo e($user2_id); ?>" data-action="<?php echo e($r->action_user_id); ?>" data-status="<?php echo e($r->status_id); ?>">Add Friend</button>
					<?php endif; ?>
					
					<?php $counter = 0; ?>
					<?php break; ?>
				<?php else: ?>
					<?php $counter++ ;?>
					<?php if($r->count() == $counter): ?>
						<td>
						<h4><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
						</td>
						<td>
						<button type="submit" class="btn btn-primary rel_btn" data-user1="<?php echo e($user1_id); ?>" data-user2="<?php echo e($user2_id); ?>" data-action="<?php echo e(Auth::user()->id); ?>" data-status="0">Add Friend</button>
						<?php $counter = 0; ?>
						<?php break; ?>
					<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
				<td>
				<h4><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h4>
				</td>
				<td>
				<button type="submit" class="btn btn-primary rel_btn" data-user1="<?php echo e($user1_id); ?>" data-user2="<?php echo e($user2_id); ?>" data-action="<?php echo e(Auth::user()->id); ?>" data-status="0">Add Friend</button>
			<?php endif; ?>
			</td>
			</tr>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<p>No Results Found.</p>
	<?php endif; ?>
	</table>

	<script>
		var urlUpdateRel = "<?php echo e(url('/updateRel')); ?>";
		var token = "<?php echo e(Session::token()); ?>";
		var userId = " <?php echo e(Auth::user()->id); ?> ";
	</script>
	<script src="<?php echo e(url('js/update_rel.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>