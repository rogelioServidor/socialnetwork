<?php $__env->startSection('title'); ?>
	Social Network - Register
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="col-md-8 col-md-offset-2">
	<?php if(Session::has('message')): ?>
		<div class="alert alert-success text-center"> <?php echo e(Session::get('message')); ?> </div>
	<?php endif; ?>
	<div class="panel panel-default">
		<div class="panel-heading">Register</div>
		<div class="panel-body">
			<form class="form-horizontal col-md-8 col-md-offset-2" action="<?php echo e(url('/register')); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

				<div class="form-group <?php echo e($errors->has('username') ? 'has-error' : ''); ?>">
				<label for="username">Username: </label>
					<input type="text" class="form-control" name="username" placeholder="Username" value="<?php echo e(old('username')); ?>">
					<?php if($errors->has('username')): ?>
						<span class="help-block">
							<?php echo e($errors->first('username')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
				<label for="email">Email: </label>
					<input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
					<?php if($errors->has('email')): ?>
						<span class="help-block">
							<?php echo e($errors->first('email')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
				<label for="password">Password: </label>
					<input type="password" class="form-control" name="password" placeholder="Password" value="<?php echo e(old('password')); ?>">
					<?php if($errors->has('password')): ?>
						<span class="help-block">
							<?php echo e($errors->first('password')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('confirmPassword') ? 'has-error' : ''); ?>">
				<label for="confirmPassword">Confirm Password: </label>
					<input type="password" class="form-control" name="confirmPassword" placeholder="Confirm Password" value="<?php echo e(old('confirmPassword')); ?>">
					<?php if($errors->has('confirmPassword')): ?>
						<span class="help-block">
							<?php echo e($errors->first('confirmPassword')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('firstname') ? 'has-error' : ''); ?>">
				<label for="firstname">First Name: </label>
					<input type="text" class="form-control" name="firstname" placeholder="First Name" value="<?php echo e(old('firstname')); ?>">
					<?php if($errors->has('firstname')): ?>
						<span class="help-block">
							<?php echo e($errors->first('firstname')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('lastname') ? 'has-error' : ''); ?>">
					<label for="lastname">Last Name: </label>
					<input type="text" class="form-control" name="lastname" placeholder="Last Name" value="<?php echo e(old('lastname')); ?>">
					<?php if($errors->has('lastname')): ?>
						<span class="help-block">
							<?php echo e($errors->first('lastname')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-primary">Register</button>
				</div>
			</form>
		</div>
	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>