@extends('layouts.master')

@section('title')
	Social Network - Index
@endsection

@section('content')
<h1>Index Page</h1>
@endsection
